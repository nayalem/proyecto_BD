<?php
session_start();
include "../config/database.php";

// Verificar que el usuario haya iniciado sesión y que sea un usuario (no administrador)
if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true || $_SESSION['user_tipo'] !== 'usuario') {
    header('Location: login.php'); // Redirigir al login si no es un usuario estándar
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Usuario</title>
    <link rel="stylesheet" href="../assets/css/estilos.css">
</head>
<body>
    <h1>Bienvenido a tu Dashboard</h1>
    <p>Hola, <?php echo htmlspecialchars($_SESSION['nombre']); ?>. Disfruta de nuestra colección de películas y funciones personalizadas para ti.</p>

    <!-- Opciones para el usuario -->
    <ul>
        <li><a href="ver_peliculas.php">Ver Películas</a></li>
        <li><a href="mi_perfil.php">Mi Perfil</a></li>
        <li><a href="historial.php">Historial de Películas</a></li>
        <li><a href="logout.php">Cerrar sesión</a></li>
    </ul>
</body>
</html>
