<?php

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Cine - Página Principal</title>
    <link rel="stylesheet" href="../assets/css/estilos.css">
</head>
<body>
    <header>
        <h1>Cine</h1>
        <nav>
            <a href="index.php">Inicio</a>
            <a href="peliculas.php">Películas</a>
        </nav>
    </header>
    <main>
