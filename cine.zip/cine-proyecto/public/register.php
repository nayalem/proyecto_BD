<?php
include "../config/database.php"; 
include "../includes/auth.php"; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $correo = $_POST['correo'];
    $contrasena = $_POST['contrasena'];
    $contrasena_hash = password_hash($contrasena, PASSWORD_DEFAULT); 

    $nombre = $_POST['nombre'];
    $prim_ape = $_POST['prim_ape'];
    $seg_ape = $_POST['seg_ape'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $tipo = "usuario"; 

    if (verificarCorreoExistente($conexion, $correo)) {
        $error_message = "El correo electrónico ya está registrado.";
    } else {
        registrarUsuario($conexion, $correo, $contrasena_hash, $nombre, $prim_ape, $seg_ape, $fecha_nacimiento, $tipo);
        echo "Registro exitoso. Ahora puedes iniciar sesión.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro de Usuario</title>
    <link rel="stylesheet" href="../assets/css/estilos.css">
</head>
<body>
    <h1>Registro de Usuario</h1>
    <?php if (isset($error_message)) { echo "<p style='color: red;'>$error_message</p>"; } ?>
    <form method="POST" action="register.php">
        <label for="correo">Correo:</label>
        <input type="email" name="correo" required><br>

        <label for="contrasena">Contraseña:</label>
        <input type="password" name="contrasena" required><br>

        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" required><br>

        <label for="prim_ape">Primer Apellido:</label>
        <input type="text" name="prim_ape" required><br>

        <label for="seg_ape">Segundo Apellido:</label>
        <input type="text" name="seg_ape" required><br>

        <label for="fecha_nacimiento">Fecha de Nacimiento:</label>
        <input type="date" name="fecha_nacimiento" required><br>

        <button type="submit">Registrar</button>
    </form>
    <p><a href="login.php">¿Ya tienes una cuenta? Inicia sesión</a></p>
</body>
</html>


