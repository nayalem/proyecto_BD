<?php
session_start();
include "../config/database.php"; 
include "../includes/auth.php"; 


if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true) {
    if ($_SESSION['user_tipo'] === 'administrador') {
        header('Location: admin_dashboard.php');
    } else {
        header('Location: user_dashboard.php');
    }
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $correo = $_POST['correo'];
    $contrasena = $_POST['contrasena'];
    $tipo = $_POST['tipo']; 

    if (loginPersonal($conexion, $correo, $contrasena, $tipo)) {
        if ($_SESSION['user_tipo'] === 'administrador') {
            header('Location: admin_dashboard.php');
        } else {
            header('Location: user_dashboard.php');
        }
        exit();
    } else {
        $error_message = "Correo, contraseña o tipo de usuario incorrectos.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="../assets/css/estilos.css">
</head>
<body>
    <h1>Iniciar sesión</h1>
    <?php if (isset($error_message)) { echo "<p style='color: red;'>$error_message</p>"; } ?>
    <form method="POST" action="login.php">
        <label for="correo">Correo:</label>
        <input type="email" name="correo" required><br>

        <label for="contrasena">Contraseña:</label>
        <input type="password" name="contrasena" required><br>

        <label for="tipo">Tipo de Usuario:</label>
        <select name="tipo" required>
            <option value="usuario">Usuario</option>
            <option value="administrador">Administrador</option>
        </select><br>

        <button type="submit">Iniciar sesión</button>
    </form>
    <p><a href="register.php">Registrarse como usuario</a></p> 
</body>
</html>


