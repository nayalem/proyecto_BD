
<?php
function verificarCorreoExistente($conexion, $correo) {
    $query = "SELECT * FROM usuarios WHERE correo = ?";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("s", $correo);
    $stmt->execute();
    $resultado = $stmt->get_result();
    return $resultado->num_rows > 0; 
}

function registrarUsuario($conexion, $correo, $contrasena_hash, $nombre, $prim_ape, $seg_ape, $fecha_nacimiento, $tipo) {
    $query = "INSERT INTO usuarios (correo, contrasena, nombre, prim_ape, seg_ape, fecha_nacimiento, tipo) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conexion->prepare($query);
    
    $stmt->bind_param("sssssss", $correo, $contrasena_hash, $nombre, $prim_ape, $seg_ape, $fecha_nacimiento, $tipo);

    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
}


function loginPersonal($conexion, $correo, $contrasena) {
    $query = "SELECT id, contrasena, tipo FROM usuario WHERE correo = ?";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("s", $correo);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $usuario = $result->fetch_assoc();

        if (password_verify($contrasena, $usuario['contrasena'])) {
            $_SESSION['user_id'] = $usuario['id'];
            $_SESSION['user_tipo'] = $usuario['tipo'];
            $_SESSION['user_logged_in'] = true;

            return true;
        }
    }
    return false; 
}

?>
