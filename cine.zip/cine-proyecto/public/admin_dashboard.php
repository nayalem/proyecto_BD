<?php
session_start();
include "../config/database.php";

// Verificar que el usuario haya iniciado sesión y que sea un administrador
if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true || $_SESSION['user_tipo'] !== 'administrador') {
    header('Location: login.php'); // Redirigir al login si no es administrador
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Administrador</title>
    <link rel="stylesheet" href="../assets/css/estilos.css">
</head>
<body>
    <h1>Bienvenido, Administrador</h1>
    <p>Hola, <?php echo htmlspecialchars($_SESSION['nombre']); ?>. Aquí puedes administrar el contenido de la plataforma.</p>

    <!-- Opciones del administrador -->
    <ul>
        <li><a href="admin_usuarios.php">Gestionar Usuarios</a></li>
        <li><a href="admin_peliculas.php">Gestionar Películas</a></li>
        <li><a href="admin_reportes.php">Ver Reportes</a></li>
        <li><a href="logout.php">Cerrar sesión</a></li>
    </ul>
</body>
</html>
