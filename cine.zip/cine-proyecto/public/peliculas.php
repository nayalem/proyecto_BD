<?php
include "../config/database.php";
include "../includes/header.php";

$query = "SELECT * FROM pelicula";
$peliculas = $conexion->query($query);

echo "<h2>Catálogo de Películas</h2><div class='peliculas'>";
foreach ($peliculas as $pelicula) {
    echo "<div class='pelicula'>
            <h3>{$pelicula['titulo']}</h3>
            <p>Año: {$pelicula['sipnosis']}</p>
            <a href='detalle.php?id={$pelicula['ID_pelicula']}'>Ver más</a>
        </div>";
}
echo "</div>";

include "../includes/footer.php";
?>
