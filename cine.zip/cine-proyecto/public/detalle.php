<?php
include "../config/database.php";
include "../includes/header.php";

// Obtener el ID de la película desde el parámetro GET, con valor por defecto de 0 si no está presente
$id = isset($_GET['ID_pelicula']) ? $_GET['ID_pelicula'] : 0;

// Preparar la consulta SQL con un marcador de posición ?
$stmt = $conexion->prepare("SELECT * FROM pelicula WHERE ID_pelicula = ?");

// Vincular el parámetro con el valor de $id
$stmt->bind_param("i", $id);  // "i" indica que el parámetro es un entero

// Ejecutar la consulta
$stmt->execute();

// Obtener los resultados
$result = $stmt->get_result();
$pelicula = $result->fetch_assoc();

// Comprobar si se encontraron datos para la película
if ($pelicula) {
    echo "<h2>{$pelicula['titulo']}</h2>";
    echo "<p><strong>Género:</strong> {$pelicula['genero']}</p>";
    echo "<p><strong>Clasificación:</strong> {$pelicula['clasificacion']}</p>";
    echo "<p><strong>Sinopsis:</strong> {$pelicula['sinopsis']}</p>";
} else {
    echo "<p>Película no encontrada.</p>";
}

include "../includes/footer.php";
?>
