<?php

function verificarCorreoExistente($conexion, $correo) {
    $stmt = $conexion->prepare("SELECT * FROM usuarios WHERE correo = ?");
    $stmt->execute([$correo]);
    return $stmt->fetch() !== false;
}


function registrarUsuario($conexion, $correo, $contrasena_hash, $nombre, $prim_ape, $seg_ape, $fecha_nacimiento, $tipo) {
    $stmt = $conexion->prepare("INSERT INTO usuarios (correo, contrasena, nombre, prim_ape, seg_ape, fecha_nacimiento, tipo) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$correo, $contrasena_hash, $nombre, $prim_ape, $seg_ape, $fecha_nacimiento, $tipo]);
}

?>
