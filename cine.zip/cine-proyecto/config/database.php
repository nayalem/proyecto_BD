<?php
$host = 'localhost'; 
$dbname = 'cine'; 
$username = 'root'; 
$password = ''; 

$conexion = new mysqli($host, $username, $password, $dbname);

if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
} else {
    echo "Conexión exitosa"; 
}
?>

