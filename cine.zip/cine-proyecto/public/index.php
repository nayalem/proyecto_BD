<?php
session_start();
include "config/database.php";

// Verificar si el usuario ya ha iniciado sesión
if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true) {
    // Redirigir al dashboard correspondiente en función del tipo de usuario
    if ($_SESSION['user_tipo'] === 'administrador') {
        header('Location: admin/admin_dashboard.php'); // Ruta hacia el dashboard del administrador
        exit();
    } elseif ($_SESSION['user_tipo'] === 'usuario') {
        header('Location: usuario/user_dashboard.php'); // Ruta hacia el dashboard del usuario
        exit();
    }
} else {
    // Mostrar una página de bienvenida o redirigir al login si el usuario no está autenticado
    header('Location: auth/login.php'); // Ruta hacia la página de login
    exit();
}
?>

